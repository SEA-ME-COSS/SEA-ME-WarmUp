#include "track.h"

Track::Track() 
{
track_info = {
            {0, 0, 1800, 1800},
            {0, 0, 1800, 1800},
            {0, 0, 1800, 1800},
            {0, 0, 1800, 1800},
            {0, 0, 1800, 1800},
            {0, 0, 1800, 1800}
        };
}


bool Track::isPointin(int point_x, int point_y) 
{
    for(int i = 0; i<track_info.size(); i++) {
        if(track_info[i][0] <= point_x && track_info[i][2] >= point_x && track_info[i][1] <= point_y && track_info[i][3] >= point_y) {
            check = true;
            break;
        }
        else
            check = false;
    }

    return check;
}